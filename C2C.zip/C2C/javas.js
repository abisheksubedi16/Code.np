var navmenu = document.getElementById("navmenu")
function hidemenu()
{
    navmenu.style.right = "-200px";
}
function showmenu()
{
    navmenu.style.right = "0";
}
