import pyttsx3 #pip install pyttsx3
import speech_recognition as sr #speechrecognition
import datetime
import wikipedia  #pip install wikipedia
import webbrowser
import os
import smtplib

engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')
engine.setProperty('voice', voices[0].id)


def speak(audio):
    engine.say(audio)
    engine.runAndWait()


def wishMe():
    hour = int(datetime.datetime.now().hour)
    if hour>=0 and hour<12:
        speak("Good Morning!")

    elif hour>=12 and hour<18:
        speak("Good Afternoon!")   

    else:
        speak("Good Evening!")  

    speak("I am Jarvis. how may I help you")       

def takeCommand():

    r = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening...")
        r.pause_threshold = 1
        audio = r.listen(source)

    try:
        print("Recognizing...")    
        query = r.recognize_google(audio, language='en-in')
        print(f"User said: {query}\n")

    except Exception as e:    
        print("Say that again please...")  
        return "None"
    return query



if __name__ == "__main__":
    wishMe()
    while True:

        query = takeCommand().lower()

        if 'wikipedia' in query:
            speak('Searching Wikipedia...')
            query = query.replace("wikipedia", "")
            results = wikipedia.summary(query, sentences=2)
            speak("According to Wikipedia")
            print(results)
            speak(results)
              #webbrowser
        elif 'Youtube' in query:
            webbrowser.open("youtube.com")

        elif 'Google' in query:
            webbrowser.open("google.com")

        elif 'Facebook' in query:
            webbrowser.open("facebook.com")   

        elif 'Messages' in query:
            webbrowser.open("facebook.com/messages")    
              #webbrowser
               
               #application
        elif 'i want to code' in query:
            speak("ok then code in vs code")
            codePath = "C:/Users/           /AppData/Local/Programs/Microsoft VS Code/Code.exe"
            os.startfile(codePath)

        elif 'Code' in query:
            codePath = "C:/Users/           /AppData/Local/Programs/Microsoft VS Code/Code.exe"
            os.startfile(codePath)

        elif 'Chrome' in query:
            chrome = "C:\Program Files\Google\Chrome\Application\chrome.exe"
            os.startfile(chrome)
               #application
               
               #time
        elif 'time' in query:
            strTime = datetime.datetime.now().strftime("%H:%M:%S")    
            speak(f"Sir, the time is {strTime}")
        elif 'date' in query:
            strTime = datetime.datetime.now().strftime("%H:%M:%S")    
            speak(f"Sir, the time is {strTime}")
               #time
               
               #qna
        elif 'jarvis' in query:
             speak("yes sir, i am here. how can i help you")

        

        elif 'how are you' in query:
             speak("i am fine. what about you")        

        elif 'fine' in query:
             speak("oh good ")        

        elif 'not good' in query:
             speak("oh take care of your self.")        

              #qna


